"""Transform registry for opactx."""
