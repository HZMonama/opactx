"""CLI package for opactx."""
