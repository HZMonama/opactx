"""Configuration models and loaders for opactx."""
