"""Core build pipeline for opactx."""
