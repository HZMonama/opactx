"""Package data for opactx templates."""
