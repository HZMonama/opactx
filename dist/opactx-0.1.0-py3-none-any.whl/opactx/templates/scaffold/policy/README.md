# Policy

Place Rego modules here. Policies can reference compiled context at `data.context.*`.
