"""Scaffold templates for opactx init."""
